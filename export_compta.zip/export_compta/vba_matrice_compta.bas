Option Explicit

'===============================================================================
' MODULE IMPORT VENTES / CAISSE + TOTAL RECHARGE CARTE
'
' FEUILLE :
'   Ecritures
'
' ZONE :
'   I1      = chemin du fichier source
'   I3:K6   = bouton
'
'===============================================================================
' SOURCE CSV :
'
'   A = Date
'   B = Journal
'   C = Général
'   D = Auxiliaire
'   E = Sens
'   F = Montant
'   G = Libellé
'
'===============================================================================
' SORTIE :
'
'   A = Date
'   B = Journal
'   C = Compte
'   D = Pièce
'   E = Libellé
'   F = Débit
'   G = Crédit
'
'===============================================================================
' TABLEAU :
'
'   Table_Ecritures
'
'===============================================================================
' LOGIQUE RECHARGE CARTE :
'
'   467201 seul
'       -> total = crédit du 467201
'
'   467201 + 708 + 44571
'       -> total = crédits des 3 comptes
'
'   467201 + 708
'       -> rien
'
'   467201 + 44571
'       -> rien
'
'   708 + 44571 sans 467201
'       -> rien
'
'   708 seul
'       -> rien
'
'   44571 seul
'       -> rien
'
'===============================================================================
' ÉCRITURE CRÉÉE :
'
'   Compte  = CCAISSE
'   Libellé = total recharge carte
'   Débit   = total
'   Crédit  = 0
'
'===============================================================================
' TRI :
'
'   1. Date
'   2. Journal
'   3. Compte
'
'===============================================================================


'===============================================================================
' PARAMÈTRES
'===============================================================================

Private Const FEUILLE_ECRITURES As String = "Ecritures"

Private Const CELLULE_CHEMIN As String = "I1"

Private Const NOM_TABLEAU As String = "Table_Ecritures"

'-------------------------------------------------------------------------------
' Couleur du tableau
'-------------------------------------------------------------------------------

Private Const COULEUR_R As Long = 47

Private Const COULEUR_G As Long = 117

Private Const COULEUR_B As Long = 181


'===============================================================================
' PROCÉDURE PRINCIPALE
'===============================================================================

Public Sub Importer_Ventes_Caisse()

    Dim ws As Worksheet

    Dim wbSource As Workbook
    Dim wsSource As Worksheet

    Dim chemin As Variant

    Dim derniereLigneSource As Long
    Dim derniereLigneImport As Long

    Dim ligneSource As Long
    Dim ligneDestination As Long

    Dim journal As String
    Dim compte As String
    Dim sens As String
    Dim libelle As String

    Dim montant As Double

    Dim ancienneCalculation As XlCalculation

    Dim tbl As ListObject
    Dim plageTableau As Range

    Dim nombreLignesImportees As Long
    Dim nombreEcrituresRecharge As Long


    On Error GoTo GestionErreur


    '===============================================================================
    ' FEUILLE DE TRAVAIL
    '===============================================================================

    Set ws = ThisWorkbook.Worksheets(FEUILLE_ECRITURES)


    '===============================================================================
    ' SAUVEGARDE DE L'ÉTAT EXCEL
    '===============================================================================

    ancienneCalculation = Application.Calculation

    Application.ScreenUpdating = False

    Application.EnableEvents = False

    Application.Calculation = xlCalculationManual


    '===============================================================================
    ' SÉLECTION DU FICHIER CSV
    '===============================================================================

    chemin = Application.GetOpenFilename( _
                FileFilter:="Fichiers CSV (*.csv),*.csv", _
                Title:="Sélectionner le fichier Ventes / Caisse")


    '-------------------------------------------------------------------------------
    ' Annulation
    '-------------------------------------------------------------------------------

    If chemin = False Then

        GoTo SortiePropre

    End If


    '===============================================================================
    ' ENREGISTREMENT DU CHEMIN SOURCE
    '===============================================================================

    ws.Range(CELLULE_CHEMIN).Value = CStr(chemin)


    '===============================================================================
    ' OUVERTURE DU CSV
    '===============================================================================

    Workbooks.Open _
        Filename:=CStr(chemin), _
        Local:=True

    Set wbSource = ActiveWorkbook

    Set wsSource = wbSource.Worksheets(1)


    '===============================================================================
    ' DERNIÈRE LIGNE DU CSV
    '===============================================================================

    derniereLigneSource = wsSource.Cells( _
                                wsSource.Rows.Count, _
                                "A").End(xlUp).Row


    '===============================================================================
    ' SUPPRESSION DE L'ANCIEN TABLEAU
    '===============================================================================

    On Error Resume Next

    Set tbl = ws.ListObjects(NOM_TABLEAU)

    If Not tbl Is Nothing Then

        tbl.Unlist

    End If

    Set tbl = Nothing

    On Error GoTo GestionErreur


    '===============================================================================
    ' NETTOYAGE DE L'ANCIEN IMPORT
    '
    ' A:G uniquement.
    '
    ' I1 et I3:K6 sont conservés.
    '===============================================================================

    ws.Range("A:G").Clear


    '===============================================================================
    ' CRÉATION DES EN-TÊTES
    '===============================================================================

    ws.Cells(1, "A").Value = "Date"

    ws.Cells(1, "B").Value = "Journal"

    ws.Cells(1, "C").Value = "Compte"

    ws.Cells(1, "D").Value = "Pièce"

    ws.Cells(1, "E").Value = "Libellé"

    ws.Cells(1, "F").Value = "Débit"

    ws.Cells(1, "G").Value = "Crédit"


    '===============================================================================
    ' PREMIÈRE LIGNE DE DESTINATION
    '===============================================================================

    ligneDestination = 2


    '===============================================================================
    ' IMPORT DU CSV
    '===============================================================================

    For ligneSource = 2 To derniereLigneSource


        '===============================================================================
        ' IGNORER LES LIGNES SANS DATE
        '===============================================================================

        If Trim$(CStr(wsSource.Cells(ligneSource, "A").Value)) <> "" Then


            '===========================================================================
            ' DATE
            '===========================================================================

            ws.Cells(ligneDestination, "A").Value = _
                ConvertirDateExport( _
                    wsSource.Cells(ligneSource, "A").Value)


            '===========================================================================
            ' JOURNAL
            '===========================================================================

            journal = Trim$( _
                        CStr( _
                            wsSource.Cells(ligneSource, "B").Value))


            Select Case UCase$(journal)

                Case "CAI", "CAISSE"

                    journal = "CAI"


                Case "VEN", "VENTE", "VENTES"

                    journal = "VEN"


                Case "PREVENTE", "PRÉVENTE"

                    journal = "PRE"


                Case Else

                    ' On conserve le journal source

            End Select


            ws.Cells(ligneDestination, "B").Value = journal


            '===========================================================================
            ' COMPTE
            '===========================================================================

            compte = Trim$( _
                        CStr( _
                            wsSource.Cells(ligneSource, "C").Value))


            ws.Cells(ligneDestination, "C").Value = compte


            '===========================================================================
            ' PIÈCE
            '===========================================================================

            ws.Cells(ligneDestination, "D").Value = ""


            '===========================================================================
            ' LIBELLÉ
            '===========================================================================

            libelle = CStr( _
                        wsSource.Cells(ligneSource, "G").Value)


            ws.Cells(ligneDestination, "E").Value = libelle


            '===========================================================================
            ' SENS
            '===========================================================================

            sens = UCase$( _
                    Trim$( _
                        CStr( _
                            wsSource.Cells(ligneSource, "E").Value)))


            '===========================================================================
            ' MONTANT
            '===========================================================================

            montant = ConvertirMontant( _
                        wsSource.Cells(ligneSource, "F").Value)


            '===========================================================================
            ' DÉBIT / CRÉDIT
            '===========================================================================

            Select Case sens


                Case "D"

                    ws.Cells(ligneDestination, "F").Value = montant

                    ws.Cells(ligneDestination, "G").Value = 0


                Case "C"

                    ws.Cells(ligneDestination, "F").Value = 0

                    ws.Cells(ligneDestination, "G").Value = montant


                Case Else

                    ws.Cells(ligneDestination, "F").Value = 0

                    ws.Cells(ligneDestination, "G").Value = 0


            End Select


            '===========================================================================
            ' LIGNE SUIVANTE
            '===========================================================================

            ligneDestination = ligneDestination + 1


        End If

    Next ligneSource


    '===============================================================================
    ' FERMETURE DU FICHIER SOURCE
    '===============================================================================

    wbSource.Close SaveChanges:=False

    Set wbSource = Nothing


    '===============================================================================
    ' NOMBRE DE LIGNES IMPORTÉES
    '===============================================================================

    derniereLigneImport = ligneDestination - 1

    nombreLignesImportees = ligneDestination - 2

    '===============================================================================
    ' NOUVELLE DERNIÈRE LIGNE
    '===============================================================================

    derniereLigneImport = ws.Cells( _
                                ws.Rows.Count, _
                                "A").End(xlUp).Row


    '===============================================================================
    ' TRI COMPLET
    '
    ' IMPORTANT :
    ' Le tri est effectué APRÈS la création des CCAISSE.
    '
    ' Donc les CCAISSE ne restent plus en bas.
    '
    ' ORDRE :
    '   Date
    '   Journal
    '   Compte
    '===============================================================================

    Trier_Ecritures ws


    '===============================================================================
    ' NOUVELLE DERNIÈRE LIGNE APRÈS LE TRI
    '===============================================================================

    derniereLigneImport = ws.Cells( _
                                ws.Rows.Count, _
                                "A").End(xlUp).Row


    '===============================================================================
    ' CRÉATION DU TABLEAU EXCEL
    '===============================================================================

    If derniereLigneImport >= 2 Then


        Set plageTableau = ws.Range( _
                                "A1:G" & derniereLigneImport)


        Set tbl = ws.ListObjects.Add( _
                        SourceType:=xlSrcRange, _
                        Source:=plageTableau, _
                        XlListObjectHasHeaders:=xlYes)


        tbl.Name = NOM_TABLEAU


        '===========================================================================
        ' STYLE DU TABLEAU
        '===========================================================================

        tbl.TableStyle = "TableStyleMedium2"


        '===========================================================================
        ' EN-TÊTES
        '===========================================================================

        With tbl.HeaderRowRange

            .Interior.Pattern = xlSolid

            .Interior.Color = RGB( _
                                COULEUR_R, _
                                COULEUR_G, _
                                COULEUR_B)

            .Font.Color = RGB(255, 255, 255)

            .Font.Bold = True

            .HorizontalAlignment = xlCenter

            .VerticalAlignment = xlCenter

        End With


        '===========================================================================
        ' DONNÉES
        '===========================================================================

        If Not tbl.DataBodyRange Is Nothing Then

            With tbl.DataBodyRange

                .Font.Color = RGB(0, 0, 0)

            End With

        End If


    End If


    '===============================================================================
    ' FORMAT DES COLONNES
    '===============================================================================

    With ws

        .Columns("A").NumberFormat = "dd/mm/yyyy"

        .Columns("F:G").NumberFormat = "#,##0.00"

        .Columns("A:G").AutoFit

    End With


    '===============================================================================
    ' BOUTON I3:K6
    '===============================================================================

    With ws.Range("I3:K6")

        .Interior.Pattern = xlSolid

        .Interior.Color = RGB( _
                            COULEUR_R, _
                            COULEUR_G, _
                            COULEUR_B)

        .Font.Color = RGB(255, 255, 255)

        .Font.Bold = True

        .HorizontalAlignment = xlCenter

        .VerticalAlignment = xlCenter

        .Borders.LineStyle = xlContinuous

        .Borders.Color = RGB(255, 255, 255)

    End With


    '===============================================================================
    ' ACTIVATION DE LA FEUILLE
    '===============================================================================

    ws.Activate


    '===============================================================================
    ' MESSAGE DE FIN
    '===============================================================================

    MsgBox _
        "Import terminé." & vbCrLf & vbCrLf & _
        nombreLignesImportees & _
        " ligne(s) importée(s)." & vbCrLf & _
        nombreEcrituresRecharge & _
        " écriture(s) CCAISSE générée(s)." & vbCrLf & vbCrLf & _
        "Tri effectué : Date ? Journal ? Compte." & vbCrLf & vbCrLf & _
        "Le fichier source a été enregistré en I1.", _
        vbInformation, _
        "Import Ventes / Caisse"


SortiePropre:

    '===============================================================================
    ' RESTAURATION EXCEL
    '===============================================================================

    Application.ScreenUpdating = True

    Application.EnableEvents = True

    Application.Calculation = ancienneCalculation

    Exit Sub


'===============================================================================
' GESTION DES ERREURS
'===============================================================================

GestionErreur:

    On Error Resume Next


    If Not wbSource Is Nothing Then

        wbSource.Close SaveChanges:=False

    End If


    Application.ScreenUpdating = True

    Application.EnableEvents = True

    Application.Calculation = ancienneCalculation


    MsgBox _
        "Erreur pendant l'import." & vbCrLf & vbCrLf & _
        "Erreur " & Err.Number & " : " & Err.Description, _
        vbCritical, _
        "Import Ventes / Caisse"

End Sub

'===============================================================================
' TRI DES ÉCRITURES
'
' ORDRE :
'
'   1. DATE
'   2. JOURNAL
'   3. COMPTE
'
' Le tri est effectué AVANT la création de Table_Ecritures.
'
' Les lignes CCAISSE sont donc incluses dans le tri.
'===============================================================================

Private Sub Trier_Ecritures( _
                        ByVal ws As Worksheet)

    Dim derniereLigne As Long

    Dim ligne As Long


    '===============================================================================
    ' DERNIÈRE LIGNE
    '===============================================================================

    derniereLigne = ws.Cells( _
                        ws.Rows.Count, _
                        "A").End(xlUp).Row


    If derniereLigne < 3 Then

        Exit Sub

    End If


    '===============================================================================
    ' CONVERSION DE TOUTES LES DATES
    '
    ' On s'assure que les dates importées et les dates CCAISSE
    ' sont toutes de vraies dates Excel.
    '===============================================================================

    For ligne = 2 To derniereLigne

        If IsDate(ws.Cells(ligne, "A").Value) Then

            ws.Cells(ligne, "A").Value = _
                CDate(ws.Cells(ligne, "A").Value)

        End If

    Next ligne


    '===============================================================================
    ' FORMAT DES DATES
    '===============================================================================

    ws.Range( _
        "A2:A" & derniereLigne).NumberFormat = _
            "dd/mm/yyyy"


    '===============================================================================
    ' TRI
    '===============================================================================

    With ws.Sort


        '---------------------------------------------------------------------------
        ' NETTOYAGE DES ANCIENS CRITÈRES
        '---------------------------------------------------------------------------

        .SortFields.Clear


        '---------------------------------------------------------------------------
        ' CRITÈRE 1 : DATE
        '---------------------------------------------------------------------------

        .SortFields.Add _
            Key:=ws.Range( _
                    "A2:A" & derniereLigne), _
            SortOn:=xlSortOnValues, _
            Order:=xlAscending, _
            DataOption:=xlSortNormal


        '---------------------------------------------------------------------------
        ' CRITÈRE 2 : JOURNAL
        '---------------------------------------------------------------------------

        .SortFields.Add _
            Key:=ws.Range( _
                    "B2:B" & derniereLigne), _
            SortOn:=xlSortOnValues, _
            Order:=xlAscending, _
            DataOption:=xlSortNormal


        '---------------------------------------------------------------------------
        ' CRITÈRE 3 : COMPTE
        '---------------------------------------------------------------------------

        .SortFields.Add _
            Key:=ws.Range( _
                    "C2:C" & derniereLigne), _
            SortOn:=xlSortOnValues, _
            Order:=xlAscending, _
            DataOption:=xlSortNormal


        '---------------------------------------------------------------------------
        ' PLAGE À TRIER
        '---------------------------------------------------------------------------

        .SetRange ws.Range( _
                    "A1:G" & derniereLigne)


        '---------------------------------------------------------------------------
        ' PREMIÈRE LIGNE = EN-TÊTES
        '---------------------------------------------------------------------------

        .Header = xlYes


        '---------------------------------------------------------------------------
        ' SENS
        '---------------------------------------------------------------------------

        .MatchCase = False

        .Orientation = xlTopToBottom


        '---------------------------------------------------------------------------
        ' APPLICATION
        '---------------------------------------------------------------------------

        .Apply

    End With

End Sub


'===============================================================================
' NETTOYAGE DU NUMÉRO DE COMPTE
'===============================================================================

Private Function NettoyerCompte( _
                            ByVal valeur As Variant) As String

    Dim texte As String


    texte = Trim$(CStr(valeur))


    texte = Replace( _
                texte, _
                " ", _
                "")


    texte = Replace( _
                texte, _
                Chr$(160), _
                "")


    '-------------------------------------------------------------------------------
    ' Gestion de 708.0 / 708,0
    '-------------------------------------------------------------------------------

    If Right$(texte, 2) = ".0" Then

        texte = Left$( _
                    texte, _
                    Len(texte) - 2)

    End If


    If Right$(texte, 2) = ",0" Then

        texte = Left$( _
                    texte, _
                    Len(texte) - 2)

    End If


    NettoyerCompte = texte

End Function


'===============================================================================
' CONVERSION DATE
'
' Exemples :
'
'   1072026 -> 01/07/2026
'   2072026 -> 02/07/2026
'   3072026 -> 03/07/2026
'
' Formats acceptés :
'
'   JMMYYYY
'   JJMMYYYY
'
'===============================================================================

Private Function ConvertirDateExport( _
                            ByVal valeur As Variant) As Variant

    Dim texte As String

    Dim jour As Integer

    Dim mois As Integer

    Dim annee As Integer


    texte = Trim$(CStr(valeur))


    If texte = "" Then

        ConvertirDateExport = ""

        Exit Function

    End If


    '===============================================================================
    ' SUPPRESSION DES ESPACES
    '===============================================================================

    texte = Replace( _
                texte, _
                " ", _
                "")


    '===============================================================================
    ' DATE NUMÉRIQUE COMPACTE
    '===============================================================================

    If IsNumeric(texte) Then


        Select Case Len(texte)


            Case 7

                '-------------------------------------------------------------------
                ' JMMYYYY
                '-------------------------------------------------------------------

                jour = CInt(Left$(texte, 1))

                mois = CInt(Mid$(texte, 2, 2))

                annee = CInt(Right$(texte, 4))


            Case 8

                '-------------------------------------------------------------------
                ' JJMMYYYY
                '-------------------------------------------------------------------

                jour = CInt(Left$(texte, 2))

                mois = CInt(Mid$(texte, 3, 2))

                annee = CInt(Right$(texte, 4))


            Case Else

                ConvertirDateExport = valeur

                Exit Function

        End Select


        '===============================================================================
        ' VALIDATION
        '===============================================================================

        If jour >= 1 And jour <= 31 _
           And mois >= 1 And mois <= 12 _
           And annee >= 2000 And annee <= 2100 Then


            ConvertirDateExport = _
                DateSerial( _
                    annee, _
                    mois, _
                    jour)


            Exit Function

        End If

    End If


    '===============================================================================
    ' DERNIER RECOURS
    '===============================================================================

    If IsDate(valeur) Then

        ConvertirDateExport = _
            CDate(valeur)

    Else

        ConvertirDateExport = _
            valeur

    End If

End Function


'===============================================================================
' CONVERSION MONTANT
'===============================================================================

Private Function ConvertirMontant( _
                            ByVal valeur As Variant) As Double

    Dim texte As String


    If IsEmpty(valeur) Then

        ConvertirMontant = 0

        Exit Function

    End If


    texte = Trim$(CStr(valeur))


    If texte = "" Then

        ConvertirMontant = 0

        Exit Function

    End If


    '===============================================================================
    ' NETTOYAGE
    '===============================================================================

    texte = Replace( _
                texte, _
                " ", _
                "")


    texte = Replace( _
                texte, _
                Chr$(160), _
                "")


    '===============================================================================
    ' NOMBRE DÉJÀ RECONNU PAR EXCEL
    '===============================================================================

    If IsNumeric(valeur) Then

        ConvertirMontant = _
            CDbl(valeur)

        Exit Function

    End If


    '===============================================================================
    ' VIRGULE / POINT
    '===============================================================================

    If InStr(texte, ",") > 0 _
       And InStr(texte, ".") = 0 Then


        texte = Replace( _
                    texte, _
                    ",", _
                    Application.DecimalSeparator)


    ElseIf InStr(texte, ".") > 0 _
           And InStr(texte, ",") = 0 Then


        texte = Replace( _
                    texte, _
                    ".", _
                    Application.DecimalSeparator)

    End If


    '===============================================================================
    ' CONVERSION
    '===============================================================================

    If IsNumeric(texte) Then

        ConvertirMontant = _
            CDbl(texte)

    Else

        ConvertirMontant = 0

    End If

End Function

